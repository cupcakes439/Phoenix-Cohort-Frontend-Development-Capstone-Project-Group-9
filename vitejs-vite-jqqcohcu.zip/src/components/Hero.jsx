import "../styles/hero.css";

function Hero() {
  return (
    <div>
      Hero
    </div>
  );
}

export default Hero;