import "../styles/navbar.css";

function Navbar() {
  return (
    <div>
      Navbar
    </div>
  );
}

export default Navbar;